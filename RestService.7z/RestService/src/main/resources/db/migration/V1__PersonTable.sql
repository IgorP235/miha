CREATE TABLE person (
  id INT NOT NULL PRIMARY KEY,
  carNum VARCHAR NOT NULL,
  registered BOOLEAN NOT NULL
);


