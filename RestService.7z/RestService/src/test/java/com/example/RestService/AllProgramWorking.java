package com.example.RestService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllProgramWorking {

	@Test
	void contextLoads() {
	}

}
